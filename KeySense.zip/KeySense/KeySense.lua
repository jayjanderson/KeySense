--[[
    KeySense
    ---------------------------------------------------------------------------
    Mythic+ applicant impact and group confidence helper.

    Version:
        0.1.3

    Purpose:
        KeySense helps a Mythic+ group leader quickly evaluate LFG applicants.

        It estimates:
            - Applicant Fit
            - Applicant Impact
            - Confidence level
            - Group utility contribution
            - Visible risk/watch items

    Important:
        This addon is guidance only.

        It does NOT:
            - Automatically invite players
            - Automatically decline players
            - Call Raider.IO, Warcraft Logs, Murlok, Wipefest, or WoWAnalyzer live
            - Pull live web data
            - Replace player judgment

    Current MVP:
        Uses Blizzard LFG applicant APIs and available in-game data.

    External Data:
        KeySenseExternalDB is supported as a placeholder for future companion-app
        imports, but no live external data is fetched by this addon.
--]]


-- ==========================================================================
-- Addon Namespace
-- ==========================================================================

local ADDON_NAME, ns = ...
local KS = CreateFrame("Frame")

ns.KeySense = KS


-- ==========================================================================
-- Constants
-- ==========================================================================

local VISIBLE_ROWS = 11
local ROW_HEIGHT = 24
local HEADER_HEIGHT = 20
local FRAME_WIDTH = 1120
local FRAME_HEIGHT = 460
local TABLE_LEFT = 22
local TABLE_TOP = -88
local TABLE_WIDTH = 1045
local COLUMN_GAP = 10

-- Fixed column layout.
-- Wide spacing is intentional because WoW font strings do not visually separate
-- columns well when several short numeric fields sit next to each other.
local COLUMNS = {
    { key = "name", title = "Applicant", width = 240, justify = "LEFT" },
    { key = "role", title = "Role", width = 72, justify = "CENTER" },
    { key = "ilvl", title = "iLvl", width = 50, justify = "CENTER" },
    { key = "score", title = "Score", width = 70, justify = "CENTER" },
    { key = "best", title = "Best", width = 54, justify = "CENTER" },
    { key = "fit", title = "Fit", width = 92, justify = "LEFT" },
    { key = "impact", title = "Impact", width = 76, justify = "CENTER" },
    { key = "conf", title = "Conf", width = 74, justify = "CENTER" },
    { key = "utility", title = "Utility", width = 235, justify = "LEFT" },
}


-- ==========================================================================
-- Color Constants
-- ==========================================================================

local GREEN  = "|cff55ff55"
local YELLOW = "|cffffff55"
local ORANGE = "|cffffaa33"
local RED    = "|cffff5555"
local BLUE   = "|cff66ccff"
local GRAY   = "|cffaaaaaa"
local WHITE  = "|cffffffff"
local RESET  = "|r"


-- ==========================================================================
-- Default Saved Variables
-- ==========================================================================

local DEFAULT_DB = {
    dbVersion = 3,

    target = {
        level = nil,
        challengeMapID = nil,
        activityID = nil,
    },

    settings = {
        -- Used when no owned keystone or manual target is detected.
        defaultKeyLevel = 10,

        -- Rough first-pass score expectation.
        -- Example: +10 expects roughly 2200 score if scorePerKey = 220.
        -- This should eventually become season-aware.
        scorePerKey = 220,

        -- Rough first-pass item level expectation.
        -- This should eventually become season-aware.
        baseExpectedIlvl = 235,
        ilvlPerKey = 3.0,

        -- Automatically show the KeySense panel when applicants update.
        autoShowOnApplicant = true,

        -- Sort applicants by impact instead of raw fit.
        sortByImpact = true,
    },

    specMeta = {
        -- Optional manual per-spec modifiers.
        --
        -- Example:
        -- [70] = 4,  -- Retribution Paladin
        --
        -- Recommended range:
        -- -8 to +8
    },

    playerNotes = {
        -- Optional local notes by exact "Name-Realm".
        --
        -- Example:
        -- ["Player-Area52"] = {
        --     bonus = 5,
        --     note = "Timed +10 with me."
        -- }
    },
}


-- ==========================================================================
-- Basic Class Utility Map
-- ==========================================================================

-- This is intentionally simple for the MVP.
-- It is not meant to be a perfect Mythic+ utility model yet.

local CLASS_UTILITY = {
    MAGE = {
        lust = true,
        curse = true,
    },

    SHAMAN = {
        lust = true,
        purge = true,
    },

    HUNTER = {
        lust = true,
        soothe = true,
    },

    EVOKER = {
        lust = true,
        soothe = true,
        poison = true,
    },

    DRUID = {
        brez = true,
        soothe = true,
        curse = true,
        poison = true,
    },

    WARLOCK = {
        brez = true,
    },

    DEATHKNIGHT = {
        brez = true,
    },

    PALADIN = {
        brez = true,
        poison = true,
        disease = true,
    },

    PRIEST = {
        magic = true,
        massDispel = true,
        disease = true,
    },

    MONK = {
        poison = true,
        disease = true,
    },

    ROGUE = {
        soothe = true,
        shroud = true,
    },

    DEMONHUNTER = {
        magicDebuff = true,
    },

    WARRIOR = {
        battleShout = true,
    },
}


local UTILITY_SHORT_NAMES = {
    ["lust"] = "BL",
    ["brez"] = "BR",
    ["purge"] = "Purge",
    ["soothe"] = "Soothe",
    ["curse"] = "Curse",
    ["poison"] = "Pois",
    ["disease"] = "Disease",
    ["magic"] = "Magic",
    ["mass dispel"] = "MD",
    ["shroud"] = "Shroud",
    ["magic debuff"] = "Chaos",
    ["battle shout"] = "BShout",
}

local UTILITY_FULL_NAMES = {
    ["lust"] = "Bloodlust / Heroism effect",
    ["brez"] = "Battle resurrection",
    ["purge"] = "Enemy purge",
    ["soothe"] = "Enrage soothe",
    ["curse"] = "Curse dispel",
    ["poison"] = "Poison dispel",
    ["disease"] = "Disease dispel",
    ["magic"] = "Magic dispel",
    ["mass dispel"] = "Mass Dispel",
    ["shroud"] = "Shroud / stealth skip",
    ["magic debuff"] = "Magic damage debuff",
    ["battle shout"] = "Battle Shout",
}


-- ==========================================================================
-- Utility Functions
-- ==========================================================================

local function CopyDefaults(src, dst)
    if type(dst) ~= "table" then
        dst = {}
    end

    for k, v in pairs(src) do
        if type(v) == "table" then
            dst[k] = CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end

    return dst
end


local function Clamp(v, minValue, maxValue)
    v = tonumber(v) or 0

    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end


local function Round(v)
    v = tonumber(v) or 0
    return math.floor(v + 0.5)
end


local function Trim(s)
    return (s or ""):match("^%s*(.-)%s*$")
end


local function SafeCall(fn, ...)
    if type(fn) ~= "function" then
        return false
    end

    return pcall(fn, ...)
end


local function ColorByImpact(v)
    v = tonumber(v) or 0

    if v >= 15 then
        return GREEN
    elseif v >= 5 then
        return BLUE
    elseif v >= -3 then
        return YELLOW
    else
        return RED
    end
end


local function FitLabel(score, confidence)
    score = tonumber(score) or 0
    confidence = tonumber(confidence) or 0

    if confidence < 35 then
        return "Unknown"
    end

    if score >= 88 then
        return "Elite"
    elseif score >= 76 then
        return "Strong"
    elseif score >= 64 then
        return "Good"
    elseif score >= 52 then
        return "Playable"
    elseif score >= 40 then
        return "High variance"
    else
        return "Risky"
    end
end


local function ConfidenceLabel(conf)
    conf = tonumber(conf) or 0

    if conf >= 80 then
        return "High"
    elseif conf >= 55 then
        return "Medium"
    elseif conf >= 35 then
        return "Low"
    else
        return "Very low"
    end
end


local function RoleText(role)
    if role == "TANK" then
        return "Tank"
    elseif role == "HEALER" then
        return "Healer"
    elseif role == "DAMAGER" then
        return "DPS"
    end

    return "?"
end


local function GroupRoleText(members)
    if type(members) ~= "table" or #members == 0 then
        return "?"
    end

    if #members == 1 then
        return RoleText(members[1].role)
    end

    local tanks = 0
    local healers = 0
    local dps = 0

    for _, member in ipairs(members) do
        if member.role == "TANK" then
            tanks = tanks + 1
        elseif member.role == "HEALER" then
            healers = healers + 1
        elseif member.role == "DAMAGER" then
            dps = dps + 1
        end
    end

    return tostring(tanks) .. "T/" .. tostring(healers) .. "H/" .. tostring(dps) .. "D"
end


local function GetSpecName(specID)
    if not specID or specID == 0 or not GetSpecializationInfoByID then
        return nil
    end

    local ok, id, name = pcall(GetSpecializationInfoByID, specID)

    if ok then
        return name
    end

    return nil
end


local function BoolIcon(v)
    if v then
        return GREEN .. "yes" .. RESET
    end

    return GRAY .. "no" .. RESET
end


local function NormalizeRealmName(name)
    name = tostring(name or "")
    name = name:gsub("%s+", "")
    return name
end


local function PlayerKey(name)
    name = tostring(name or "")

    if name == "" then
        return nil
    end

    if name:find("-", 1, true) then
        return name
    end

    local realm = GetRealmName and GetRealmName() or nil

    if realm and realm ~= "" then
        return name .. "-" .. NormalizeRealmName(realm)
    end

    return name
end


local function UtilityListForClass(classFile)
    local utility = CLASS_UTILITY[classFile or ""]
    local parts = {}

    if not utility then
        return parts
    end

    if utility.lust then
        table.insert(parts, "lust")
    end

    if utility.brez then
        table.insert(parts, "brez")
    end

    if utility.purge then
        table.insert(parts, "purge")
    end

    if utility.soothe then
        table.insert(parts, "soothe")
    end

    if utility.curse then
        table.insert(parts, "curse")
    end

    if utility.poison then
        table.insert(parts, "poison")
    end

    if utility.disease then
        table.insert(parts, "disease")
    end

    if utility.magic then
        table.insert(parts, "magic")
    end

    if utility.massDispel then
        table.insert(parts, "mass dispel")
    end

    if utility.shroud then
        table.insert(parts, "shroud")
    end

    if utility.magicDebuff then
        table.insert(parts, "magic debuff")
    end

    if utility.battleShout then
        table.insert(parts, "battle shout")
    end

    return parts
end


local function UtilityShortLabel(tag)
    return UTILITY_SHORT_NAMES[tag] or tag
end


local function UtilityFullLabel(tag)
    return UTILITY_FULL_NAMES[tag] or tag
end


local function UtilityShortText(tags, maxVisible)
    if type(tags) ~= "table" or #tags == 0 then
        return "-"
    end

    maxVisible = tonumber(maxVisible) or 3

    local parts = {}
    local visibleCount = math.min(#tags, maxVisible)

    for i = 1, visibleCount do
        table.insert(parts, UtilityShortLabel(tags[i]))
    end

    if #tags > visibleCount then
        table.insert(parts, "+" .. tostring(#tags - visibleCount))
    end

    return table.concat(parts, ", ")
end


local function UtilityFullText(tags)
    if type(tags) ~= "table" or #tags == 0 then
        return "None detected"
    end

    local parts = {}

    for _, tag in ipairs(tags) do
        table.insert(parts, UtilityFullLabel(tag))
    end

    return table.concat(parts, ", ")
end


local function TruncateText(text, maxChars)
    text = tostring(text or "")
    maxChars = tonumber(maxChars) or 20

    if #text <= maxChars then
        return text
    end

    if maxChars <= 3 then
        return text:sub(1, maxChars)
    end

    return text:sub(1, maxChars - 3) .. "..."
end


local function ShortConfidenceLabel(label)
    if label == "Medium" then
        return "Med"
    elseif label == "Very low" then
        return "VLow"
    end

    return label or "-"
end


local function ShortFitLabel(label)
    if label == "High variance" then
        return "High var"
    end

    return label or "-"
end


local function UtilityScoreForClass(classFile)
    local utility = CLASS_UTILITY[classFile or ""]
    local score = 0

    if not utility then
        return 0
    end

    if utility.lust then
        score = score + 8
    end

    if utility.brez then
        score = score + 7
    end

    if utility.purge then
        score = score + 3
    end

    if utility.soothe then
        score = score + 3
    end

    if utility.massDispel then
        score = score + 4
    end

    if utility.shroud then
        score = score + 3
    end

    if utility.magicDebuff then
        score = score + 3
    end

    if utility.battleShout then
        score = score + 2
    end

    if utility.curse or utility.poison or utility.disease or utility.magic then
        score = score + 2
    end

    return Clamp(score, 0, 14)
end


local function FirstNumberFromTable(t, keys)
    if type(t) ~= "table" then
        return nil
    end

    for _, key in ipairs(keys) do
        local value = t[key]

        if type(value) == "number" then
            return value
        end
    end

    return nil
end


local function ScanStatsForNumber(t, wantedKeys)
    if type(t) ~= "table" then
        return nil
    end

    local direct = FirstNumberFromTable(t, wantedKeys)

    if direct then
        return direct
    end

    for _, value in pairs(t) do
        if type(value) == "table" then
            local nested = ScanStatsForNumber(value, wantedKeys)

            if nested then
                return nested
            end
        end
    end

    return nil
end


-- ==========================================================================
-- Basic Addon Methods
-- ==========================================================================

function KS:Print(msg)
    print(BLUE .. "KeySense:" .. RESET .. " " .. tostring(msg))
end


function KS:MigrateDB()
    if type(KeySenseDB) ~= "table" then
        KeySenseDB = CopyDefaults(DEFAULT_DB, {})
    end

    KeySenseDB.settings = KeySenseDB.settings or {}

    -- 0.1.0-0.1.2 used a Dragonflight/War Within-style ilvl baseline.
    -- Current Midnight test values in the group finder are around the 260-290 range,
    -- so migrate old saved settings automatically instead of requiring /ks reset.
    if KeySenseDB.settings.baseExpectedIlvl == nil or KeySenseDB.settings.baseExpectedIlvl >= 600 then
        KeySenseDB.settings.baseExpectedIlvl = DEFAULT_DB.settings.baseExpectedIlvl
    end

    if KeySenseDB.settings.ilvlPerKey == nil or KeySenseDB.settings.ilvlPerKey == 3.5 then
        KeySenseDB.settings.ilvlPerKey = DEFAULT_DB.settings.ilvlPerKey
    end

    if KeySenseDB.settings.scorePerKey == nil then
        KeySenseDB.settings.scorePerKey = DEFAULT_DB.settings.scorePerKey
    end

    KeySenseDB.dbVersion = DEFAULT_DB.dbVersion
end


function KS:InitDB()
    KeySenseDB = CopyDefaults(DEFAULT_DB, KeySenseDB or {})
    KeySenseExternalDB = KeySenseExternalDB or {}

    self:MigrateDB()
    self.db = KeySenseDB
end


-- ==========================================================================
-- Keystone / Target Context
-- ==========================================================================

function KS:GetOwnedKeyContext()
    local level
    local challengeMapID

    if C_MythicPlus then
        local okLevel, resultLevel = SafeCall(C_MythicPlus.GetOwnedKeystoneLevel)

        if okLevel and type(resultLevel) == "number" and resultLevel > 0 then
            level = resultLevel
        end

        local okMap, resultMap = SafeCall(C_MythicPlus.GetOwnedKeystoneChallengeMapID)

        if okMap and type(resultMap) == "number" and resultMap > 0 then
            challengeMapID = resultMap
        end
    end

    return {
        level = level,
        challengeMapID = challengeMapID,
    }
end


function KS:GetActiveActivityID()
    if not C_LFGList or type(C_LFGList.GetActiveEntryInfo) ~= "function" then
        return nil
    end

    local ok, entry = pcall(C_LFGList.GetActiveEntryInfo)

    if not ok or type(entry) ~= "table" then
        return nil
    end

    if type(entry.activityID) == "number" then
        return entry.activityID
    end

    if type(entry.activityIDs) == "table" then
        for _, activityID in ipairs(entry.activityIDs) do
            if type(activityID) == "number" then
                return activityID
            end
        end
    end

    return nil
end


function KS:GetTargetContext()
    local owned = self:GetOwnedKeyContext()
    local target = self.db and self.db.target or {}
    local settings = self.db and self.db.settings or DEFAULT_DB.settings

    local activeActivityID = self:GetActiveActivityID()

    return {
        level = target.level or owned.level or settings.defaultKeyLevel,
        challengeMapID = target.challengeMapID or owned.challengeMapID,
        activityID = target.activityID or activeActivityID,
        source = target.level and "manual" or (owned.level and "owned key" or "default"),
    }
end


function KS:SetTargetLevel(level)
    level = tonumber(level)

    if not level or level < 2 or level > 40 then
        self:Print("Usage: /ks level 10")
        return
    end

    self.db.target.level = Round(level)
    self:Print("Target key level set to +" .. tostring(self.db.target.level) .. ".")
    self:Refresh()
end


function KS:ClearTarget()
    self.db.target.level = nil
    self.db.target.challengeMapID = nil
    self.db.target.activityID = nil

    self:Print("Manual target cleared.")
    self:Refresh()
end


-- ==========================================================================
-- Applicant Data
-- ==========================================================================

function KS:GetApplicantIDs()
    if not C_LFGList or type(C_LFGList.GetApplicants) ~= "function" then
        return {}
    end

    local ok, applicants = pcall(C_LFGList.GetApplicants)

    if ok and type(applicants) == "table" then
        return applicants
    end

    return {}
end


function KS:GetApplicantInfo(applicantID)
    local info = {
        applicantID = applicantID,
        status = nil,
        numMembers = 1,
        isNew = false,
    }

    if C_LFGList and type(C_LFGList.GetApplicantInfo) == "function" then
        local ok, a, status, pendingStatus, numMembers, isNew, comment, displayOrderID = pcall(C_LFGList.GetApplicantInfo, applicantID)

        if ok then
            if type(a) == "table" then
                info.status = a.applicationStatus or a.status
                info.pendingStatus = a.pendingApplicationStatus or a.pendingStatus
                info.numMembers = a.numMembers or a.memberCount or 1
                info.isNew = a.isNew or false
                info.comment = a.comment
                info.displayOrderID = a.displayOrderID
            else
                info.status = status
                info.pendingStatus = pendingStatus
                info.numMembers = numMembers or 1
                info.isNew = isNew or false
                info.comment = comment
                info.displayOrderID = displayOrderID
            end
        end
    end

    info.numMembers = tonumber(info.numMembers) or 1

    if info.numMembers < 1 then
        info.numMembers = 1
    end

    return info
end


function KS:GetApplicantMemberInfo(applicantID, memberIndex, activityID)
    local member = {
        applicantID = applicantID,
        memberIndex = memberIndex,
        name = "Unknown",
        classFile = nil,
        localizedClass = nil,
        level = nil,
        itemLevel = nil,
        role = nil,
        specID = nil,
        specName = nil,
        score = nil,
        bestRunLevel = nil,
        bestDungeonMapScore = nil,
        bestDungeonMapName = nil,
        isLeaver = nil,
    }

    if not C_LFGList or type(C_LFGList.GetApplicantMemberInfo) ~= "function" then
        return member
    end

    local ok, name, classFile, localizedClass, level, itemLevel, honorLevel, tank, healer, damage, assignedRole, relationship, dungeonScore, pvpItemLevel, factionGroup, raceID, specID, isLeaver = pcall(C_LFGList.GetApplicantMemberInfo, applicantID, memberIndex)

    if ok then
        if type(name) == "table" then
            local data = name
            member.name = data.name or data.playerName or member.name
            member.classFile = data.classFilename or data.classFileName or data.classFile or data.class
            member.localizedClass = data.localizedClass or data.className
            member.level = data.level
            member.itemLevel = data.itemLevel or data.ilvl
            member.role = data.assignedRole or data.role
            member.score = tonumber(data.dungeonScore or data.mythicPlusScore or data.score)
            member.pvpItemLevel = tonumber(data.pvpItemLevel)
            member.specID = data.specID or data.specId
            member.isLeaver = data.isLeaver
        else
            member.name = name or member.name
            member.classFile = classFile
            member.localizedClass = localizedClass
            member.level = level
            member.itemLevel = itemLevel
            member.role = assignedRole
            member.score = tonumber(dungeonScore)
            member.pvpItemLevel = tonumber(pvpItemLevel)
            member.specID = specID
            member.isLeaver = isLeaver

            if not member.role then
                if tank then
                    member.role = "TANK"
                elseif healer then
                    member.role = "HEALER"
                elseif damage then
                    member.role = "DAMAGER"
                end
            end
        end
    end

    member.itemLevel = tonumber(member.itemLevel)
    member.level = tonumber(member.level)
    member.specID = tonumber(member.specID)
    member.specName = GetSpecName(member.specID)

    self:AddApplicantBestDungeonScore(member, activityID)
    self:AddApplicantStats(member)

    return member
end


function KS:AddApplicantBestDungeonScore(member, activityID)
    if not C_LFGList then
        return
    end

    local scoreInfo

    if type(C_LFGList.GetApplicantBestDungeonScore) == "function" then
        local ok, result = pcall(C_LFGList.GetApplicantBestDungeonScore, member.applicantID, member.memberIndex)

        if ok and type(result) == "table" then
            scoreInfo = result
        end
    end

    if not scoreInfo and activityID and type(C_LFGList.GetApplicantDungeonScoreForListing) == "function" then
        local ok, result = pcall(C_LFGList.GetApplicantDungeonScoreForListing, member.applicantID, member.memberIndex, activityID)

        if ok and type(result) == "table" then
            scoreInfo = result
        end
    end

    if type(scoreInfo) ~= "table" then
        return
    end

    if type(scoreInfo.bestRunLevel) == "number" then
        member.bestRunLevel = scoreInfo.bestRunLevel
    end

    if type(scoreInfo.mapScore) == "number" then
        member.bestDungeonMapScore = scoreInfo.mapScore
    end

    if type(scoreInfo.mapName) == "string" then
        member.bestDungeonMapName = scoreInfo.mapName
    end
end


function KS:AddApplicantStats(member)
    if not C_LFGList or type(C_LFGList.GetApplicantMemberStats) ~= "function" then
        return
    end

    local ok, stats = pcall(C_LFGList.GetApplicantMemberStats, member.applicantID, member.memberIndex)

    if not ok or type(stats) ~= "table" then
        return
    end

    member.rawStats = stats

    -- GetApplicantMemberStats is primarily Proving Grounds data in current Retail,
    -- not the Mythic+ rating shown in the applicant list. Do not overwrite the
    -- dungeonScore returned by GetApplicantMemberInfo.
    if not member.bestRunLevel then
        member.bestRunLevel = ScanStatsForNumber(stats, {
            "bestRunLevel",
            "bestDungeonLevel",
            "mythicLevel",
            "keystoneLevel",
        })
    end
end


function KS:GetApplicants()
    local result = {}
    local applicantIDs = self:GetApplicantIDs()
    local activeActivityID = self:GetActiveActivityID()

    for _, applicantID in ipairs(applicantIDs) do
        local info = self:GetApplicantInfo(applicantID)

        if info.status == "applied" or info.status == "invited" or info.status == nil then
            local members = {}

            info.activityID = activeActivityID

            for memberIndex = 1, info.numMembers do
                table.insert(members, self:GetApplicantMemberInfo(applicantID, memberIndex, activeActivityID))
            end

            local summary = self:EvaluateApplicant(info, members)

            table.insert(result, summary)
        end
    end

    if self.db.settings.sortByImpact then
        table.sort(result, function(a, b)
            if a.impact == b.impact then
                return a.fit > b.fit
            end

            return a.impact > b.impact
        end)
    else
        table.sort(result, function(a, b)
            if a.fit == b.fit then
                return a.impact > b.impact
            end

            return a.fit > b.fit
        end)
    end

    return result
end


-- ==========================================================================
-- Scoring
-- ==========================================================================

function KS:EvaluateApplicant(info, members)
    local target = self:GetTargetContext()
    local settings = self.db.settings
    local targetLevel = tonumber(target.level) or settings.defaultKeyLevel
    local expectedScore = targetLevel * settings.scorePerKey
    local expectedIlvl = settings.baseExpectedIlvl + (targetLevel * settings.ilvlPerKey)

    local best = nil
    local utilityScore = 0
    local utilityTags = {}
    local avgIlvl = 0
    local ilvlCount = 0
    local bestScore = nil
    local bestRunLevel = nil
    local confidence = 20
    local noteBonus = 0
    local noteText = nil
    local specBonus = 0

    for _, member in ipairs(members) do
        if not best then
            best = member
        end

        local classUtilityScore = UtilityScoreForClass(member.classFile)
        utilityScore = utilityScore + classUtilityScore

        local classUtilityTags = UtilityListForClass(member.classFile)

        for _, tag in ipairs(classUtilityTags) do
            utilityTags[tag] = true
        end

        if member.itemLevel then
            avgIlvl = avgIlvl + member.itemLevel
            ilvlCount = ilvlCount + 1
        end

        if member.score and (not bestScore or member.score > bestScore) then
            bestScore = member.score
        end

        if member.bestRunLevel and (not bestRunLevel or member.bestRunLevel > bestRunLevel) then
            bestRunLevel = member.bestRunLevel
        end

        if member.specID and self.db.specMeta[member.specID] then
            specBonus = specBonus + (tonumber(self.db.specMeta[member.specID]) or 0)
        end

        local key = PlayerKey(member.name)
        local note = key and self.db.playerNotes[key] or nil

        if type(note) == "table" then
            noteBonus = noteBonus + (tonumber(note.bonus) or 0)
            noteText = note.note or noteText
        end
    end

    if ilvlCount > 0 then
        avgIlvl = avgIlvl / ilvlCount
        confidence = confidence + 25
    else
        avgIlvl = nil
    end

    if bestScore then
        confidence = confidence + 40
    end

    if bestRunLevel then
        confidence = confidence + 15
    end

    if best and best.role then
        confidence = confidence + 10
    end

    if #members > 1 then
        confidence = confidence - 10
    end

    confidence = Clamp(confidence, 10, 95)

    local ilvlScore = 0

    if avgIlvl then
        ilvlScore = Clamp((avgIlvl - expectedIlvl) * 1.5, -18, 18)
    end

    local ratingScore = 0

    if bestScore then
        ratingScore = Clamp((bestScore - expectedScore) / 45, -26, 26)
    else
        -- Unknown score should lower confidence, not automatically bury the applicant.
        ratingScore = -4
    end

    local completionScore = 0

    if bestRunLevel then
        completionScore = Clamp((bestRunLevel - targetLevel) * 3, -12, 12)
    end

    if #members > 1 then
        utilityScore = utilityScore / math.max(#members, 1) + math.min(#members - 1, 4)
    end

    utilityScore = Clamp(utilityScore, 0, 20)
    specBonus = Clamp(specBonus, -12, 12)
    noteBonus = Clamp(noteBonus, -15, 15)

    local fit = 55 + ilvlScore + ratingScore + completionScore + specBonus + noteBonus
    fit = Clamp(Round(fit), 0, 100)

    local impact = (fit - 55) + utilityScore + specBonus + noteBonus

    local tags = {}

    for tag in pairs(utilityTags) do
        table.insert(tags, tag)
    end

    table.sort(tags)

    return {
        applicantID = info.applicantID,
        members = members,
        primary = best or members[1],
        memberCount = #members,
        fit = fit,
        impact = Round(impact),
        confidence = Round(confidence),
        fitLabel = FitLabel(fit, confidence),
        confidenceLabel = ConfidenceLabel(confidence),
        utilityScore = utilityScore,
        utilityTags = tags,
        avgIlvl = avgIlvl and Round(avgIlvl) or nil,
        score = bestScore,
        bestRunLevel = bestRunLevel,
        note = noteText,
        targetLevel = targetLevel,
        targetSource = target.source,
        comment = info.comment,
    }
end


-- ============================================================================
-- UI
-- ============================================================================

local function CreateColumnText(parent, column, fontObject)
    local text = parent:CreateFontString(nil, "OVERLAY", fontObject or "GameFontHighlightSmall")
    text:SetWidth(column.width)
    text:SetHeight(ROW_HEIGHT)
    text:SetJustifyH(column.justify or "LEFT")
    text:SetJustifyV("MIDDLE")
    text:SetWordWrap(false)

    if text.SetNonSpaceWrap then
        text:SetNonSpaceWrap(false)
    end

    return text
end


function KS:CreateUI()
    if self.frame then
        return
    end

    local frame = CreateFrame("Frame", "KeySenseFrame", UIParent, "BackdropTemplate")
    frame:SetSize(FRAME_WIDTH, FRAME_HEIGHT)
    frame:SetPoint("CENTER")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:Hide()

    if frame.SetBackdrop then
        frame:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile = true,
            tileSize = 32,
            edgeSize = 32,
            insets = {
                left = 8,
                right = 8,
                top = 8,
                bottom = 8,
            },
        })

        frame:SetBackdropColor(0, 0, 0, 0.92)
    end

    frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    frame.title:SetPoint("TOPLEFT", 18, -16)
    frame.title:SetText(BLUE .. "KeySense" .. RESET)

    frame.subtitle = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    frame.subtitle:SetPoint("TOPLEFT", frame.title, "BOTTOMLEFT", 0, -6)
    frame.subtitle:SetText(GRAY .. "Mythic+ applicant impact helper" .. RESET)

    frame.context = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    frame.context:SetPoint("TOPRIGHT", -52, -20)
    frame.context:SetJustifyH("RIGHT")

    frame.close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    frame.close:SetPoint("TOPRIGHT", -5, -5)

    frame.refresh = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.refresh:SetSize(86, 22)
    frame.refresh:SetPoint("TOPRIGHT", -55, -48)
    frame.refresh:SetText("Refresh")
    frame.refresh:SetScript("OnClick", function()
        KS:Refresh()
    end)

    frame.headerFrame = CreateFrame("Frame", nil, frame)
    frame.headerFrame:SetSize(TABLE_WIDTH, HEADER_HEIGHT)
    frame.headerFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", TABLE_LEFT, TABLE_TOP)

    frame.headers = {}

    local offsetX = 0

    for _, column in ipairs(COLUMNS) do
        local header = CreateColumnText(frame.headerFrame, column, "GameFontNormalSmall")
        header:SetPoint("LEFT", frame.headerFrame, "LEFT", offsetX, 0)
        header:SetText(WHITE .. column.title .. RESET)
        frame.headers[column.key] = header
        column.offsetX = offsetX
        offsetX = offsetX + column.width + COLUMN_GAP
    end

    frame.scrollFrame = CreateFrame("ScrollFrame", "KeySenseApplicantScrollFrame", frame, "UIPanelScrollFrameTemplate")
    frame.scrollFrame:SetSize(TABLE_WIDTH, VISIBLE_ROWS * ROW_HEIGHT)
    frame.scrollFrame:SetPoint("TOPLEFT", frame.headerFrame, "BOTTOMLEFT", 0, -4)

    frame.scrollChild = CreateFrame("Frame", nil, frame.scrollFrame)
    frame.scrollChild:SetSize(TABLE_WIDTH, VISIBLE_ROWS * ROW_HEIGHT)
    frame.scrollFrame:SetScrollChild(frame.scrollChild)

    frame.scrollFrame:EnableMouseWheel(true)
    frame.scrollFrame:SetScript("OnMouseWheel", function(scrollFrame, delta)
        KS:ScrollApplicants(delta)
    end)

    frame.rows = {}

    frame.empty = frame.scrollChild:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    frame.empty:SetPoint("TOPLEFT", frame.scrollChild, "TOPLEFT", 0, -5)
    frame.empty:SetWidth(TABLE_WIDTH - 20)
    frame.empty:SetJustifyH("LEFT")
    frame.empty:SetText("")

    frame.count = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    frame.count:SetPoint("BOTTOMRIGHT", -46, 18)
    frame.count:SetJustifyH("RIGHT")
    frame.count:SetText("")

    frame.footer = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    frame.footer:SetPoint("BOTTOMLEFT", 22, 18)
    frame.footer:SetWidth(650)
    frame.footer:SetJustifyH("LEFT")
    frame.footer:SetText("Commands: /ks, /ks scan, /ks level 10, /ks clear, /ks reset")

    self.frame = frame
end


function KS:Show()
    self:CreateUI()
    self.frame:Show()
    self:Refresh()
end


function KS:Hide()
    if self.frame then
        self.frame:Hide()
    end
end


function KS:Toggle()
    self:CreateUI()

    if self.frame:IsShown() then
        self.frame:Hide()
    else
        self.frame:Show()
        self:Refresh()
    end
end


function KS:ScrollApplicants(delta)
    if not self.frame or not self.frame.scrollFrame then
        return
    end

    local scrollFrame = self.frame.scrollFrame
    local current = scrollFrame:GetVerticalScroll() or 0
    local step = ROW_HEIGHT * 3
    local maxScroll = 0

    if scrollFrame.GetVerticalScrollRange then
        maxScroll = scrollFrame:GetVerticalScrollRange() or 0
    end

    local target = current - ((tonumber(delta) or 0) * step)

    if target < 0 then
        target = 0
    elseif target > maxScroll then
        target = maxScroll
    end

    scrollFrame:SetVerticalScroll(target)
end


function KS:EnsureRow(index)
    self:CreateUI()

    if self.frame.rows[index] then
        return self.frame.rows[index]
    end

    local row = CreateFrame("Frame", nil, self.frame.scrollChild)
    row:SetSize(TABLE_WIDTH, ROW_HEIGHT)
    row:SetPoint("TOPLEFT", self.frame.scrollChild, "TOPLEFT", 0, -((index - 1) * ROW_HEIGHT))
    row:EnableMouse(true)

    row.bg = row:CreateTexture(nil, "BACKGROUND")
    row.bg:SetAllPoints()

    if row.bg.SetColorTexture then
        local alpha = (index % 2 == 0) and 0.035 or 0.015
        row.bg:SetColorTexture(1, 1, 1, alpha)
    end

    row.columns = {}

    for _, column in ipairs(COLUMNS) do
        local text = CreateColumnText(row, column, "GameFontHighlightSmall")
        text:SetPoint("LEFT", row, "LEFT", column.offsetX or 0, 0)
        row.columns[column.key] = text
    end

    row:SetScript("OnEnter", function(rowFrame)
        KS:ShowApplicantTooltip(rowFrame.applicant, rowFrame)
    end)

    row:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    row:SetScript("OnMouseWheel", function(_, delta)
        KS:ScrollApplicants(delta)
    end)

    self.frame.rows[index] = row

    return row
end


function KS:BuildApplicantDisplay(applicant)
    local primary = applicant.primary or {}
    local name = primary.name or "Unknown"

    if applicant.memberCount and applicant.memberCount > 1 then
        name = name .. " +" .. tostring(applicant.memberCount - 1)
    end

    local ilvl = applicant.avgIlvl and tostring(applicant.avgIlvl) or "-"
    local score = applicant.score and tostring(Round(applicant.score)) or "-"
    local best = applicant.bestRunLevel and ("+" .. tostring(Round(applicant.bestRunLevel))) or "-"
    local fit = ShortFitLabel(applicant.fitLabel) .. " " .. tostring(applicant.fit or "-")
    local impact = ColorByImpact(applicant.impact) .. string.format("%+d", tonumber(applicant.impact) or 0) .. RESET
    local conf = ShortConfidenceLabel(applicant.confidenceLabel) .. " " .. tostring(applicant.confidence or "-")
    local utility = UtilityShortText(applicant.utilityTags, 4)

    return {
        name = TruncateText(name, 31),
        role = GroupRoleText(applicant.members),
        ilvl = ilvl,
        score = score,
        best = best,
        fit = TruncateText(fit, 14),
        impact = impact,
        conf = TruncateText(conf, 10),
        utility = TruncateText(utility, 34),
    }
end


function KS:ShowApplicantTooltip(applicant, owner)
    if not applicant or not owner or not GameTooltip then
        return
    end

    local primary = applicant.primary or {}

    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:SetText("KeySense Applicant", 1, 1, 1)

    if applicant.memberCount and applicant.memberCount > 1 then
        GameTooltip:AddLine("Group applicant: " .. tostring(applicant.memberCount) .. " members", 1, 0.82, 0)
    else
        GameTooltip:AddLine(primary.name or "Unknown", 0.66, 0.8, 1)
    end

    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(
        "Fit: " .. tostring(applicant.fitLabel) .. " " .. tostring(applicant.fit)
            .. "   Impact: " .. string.format("%+d", tonumber(applicant.impact) or 0)
            .. "   Confidence: " .. tostring(applicant.confidenceLabel) .. " " .. tostring(applicant.confidence),
        0.9, 0.9, 0.9
    )

    GameTooltip:AddLine("Utility: " .. UtilityFullText(applicant.utilityTags), 0.85, 0.85, 0.85, true)

    if applicant.targetLevel then
        GameTooltip:AddLine("Target: +" .. tostring(applicant.targetLevel) .. " (" .. tostring(applicant.targetSource or "unknown") .. ")", 0.65, 0.65, 0.65)
    end

    if applicant.avgIlvl or applicant.score or applicant.bestRunLevel then
        GameTooltip:AddLine(
            "Seen data: iLvl " .. tostring(applicant.avgIlvl or "-")
                .. "   Score " .. tostring(applicant.score and Round(applicant.score) or "-")
                .. "   Best " .. tostring(applicant.bestRunLevel and ("+" .. Round(applicant.bestRunLevel)) or "-"),
            0.65, 0.65, 0.65
        )
    end

    if applicant.comment and applicant.comment ~= "" then
        GameTooltip:AddLine("Comment: " .. tostring(applicant.comment), 0.7, 0.7, 0.7, true)
    end

    if applicant.note and applicant.note ~= "" then
        GameTooltip:AddLine("Note: " .. tostring(applicant.note), 0.7, 0.9, 0.7, true)
    end

    local members = applicant.members or {}

    if #members > 0 then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Members", 1, 1, 1)

        for _, member in ipairs(members) do
            local memberName = member.name or "Unknown"
            local memberRole = RoleText(member.role)
            local memberIlvl = member.itemLevel and tostring(Round(member.itemLevel)) or "-"
            local memberScore = member.score and tostring(Round(member.score)) or "-"
            local memberBest = member.bestRunLevel and ("+" .. tostring(Round(member.bestRunLevel))) or "-"
            local memberSpec = member.specName or member.localizedClass or member.classFile or ""

            GameTooltip:AddLine("• " .. memberName, 1, 1, 1)
            GameTooltip:AddLine(
                "  " .. memberRole .. "  " .. memberSpec
                    .. "  iLvl " .. memberIlvl
                    .. "  Score " .. memberScore
                    .. "  Best " .. memberBest,
                0.72, 0.72, 0.72
            )
        end
    end

    GameTooltip:Show()
end


function KS:RenderApplicantRows(applicants)
    self:CreateUI()

    applicants = applicants or {}

    local totalRows = math.max(#applicants, 1)
    local childHeight = math.max(totalRows * ROW_HEIGHT, VISIBLE_ROWS * ROW_HEIGHT)

    self.frame.scrollChild:SetSize(TABLE_WIDTH, childHeight)

    if self.frame.scrollFrame.SetVerticalScroll then
        self.frame.scrollFrame:SetVerticalScroll(0)
    end

    if #applicants == 0 then
        self.frame.empty:SetText(GRAY .. "No active LFG applicants found. Open your Group Finder listing and click Refresh." .. RESET)
    else
        self.frame.empty:SetText("")
    end

    for i, applicant in ipairs(applicants) do
        local row = self:EnsureRow(i)
        local display = self:BuildApplicantDisplay(applicant)

        row.applicant = applicant
        row:Show()

        for key, value in pairs(display) do
            if row.columns[key] then
                row.columns[key]:SetText(value)
            end
        end
    end

    for i = #applicants + 1, #self.frame.rows do
        local row = self.frame.rows[i]
        row.applicant = nil
        row:Hide()
    end

    if #applicants == 0 then
        self.frame.count:SetText("")
    elseif #applicants > VISIBLE_ROWS then
        self.frame.count:SetText(GRAY .. tostring(#applicants) .. " applicants - scroll for more" .. RESET)
    else
        self.frame.count:SetText(GRAY .. tostring(#applicants) .. " applicant" .. (#applicants == 1 and "" or "s") .. RESET)
    end
end


function KS:Refresh()
    self:CreateUI()

    local context = self:GetTargetContext()
    self.frame.context:SetText(
        WHITE .. "Target: +" .. tostring(context.level) .. RESET
        .. GRAY .. " (" .. tostring(context.source) .. ")" .. RESET
    )

    local applicants = self:GetApplicants()
    self.currentApplicants = applicants
    self:RenderApplicantRows(applicants)
end


-- ==========================================================================
-- Slash Commands
-- ==========================================================================

function KS:PrintHelp()
    self:Print("/ks - show or hide KeySense")
    self:Print("/ks scan - refresh applicant list")
    self:Print("/ks level <number> - set manual target key level")
    self:Print("/ks clear - clear manual target key")
    self:Print("/ks reset - reset KeySense settings")
end


function KS:ResetDB()
    KeySenseDB = CopyDefaults(DEFAULT_DB, {})
    KeySenseExternalDB = KeySenseExternalDB or {}
    self.db = KeySenseDB

    self:Print("Settings reset.")
    self:Refresh()
end


function KS:HandleSlash(msg)
    msg = Trim(msg)
    local command, rest = msg:match("^(%S*)%s*(.-)$")
    command = string.lower(command or "")
    rest = Trim(rest)

    if command == "" then
        self:Toggle()
    elseif command == "show" or command == "open" then
        self:Show()
    elseif command == "hide" or command == "close" then
        self:Hide()
    elseif command == "scan" or command == "refresh" then
        self:Show()
        self:Refresh()
    elseif command == "level" or command == "key" then
        self:SetTargetLevel(rest)
    elseif command == "clear" then
        self:ClearTarget()
    elseif command == "reset" then
        self:ResetDB()
    elseif command == "help" then
        self:PrintHelp()
    else
        self:Print("Unknown command: " .. command)
        self:PrintHelp()
    end
end


-- ==========================================================================
-- Events
-- ==========================================================================

function KS:RegisterGameEvent(eventName)
    local ok = pcall(self.RegisterEvent, self, eventName)

    return ok
end


function KS:OnAddonLoaded(addonName)
    if addonName ~= ADDON_NAME then
        return
    end

    self:InitDB()
    self:CreateUI()

    SLASH_KEYSENSE1 = "/keysense"
    SLASH_KEYSENSE2 = "/ks"
    SlashCmdList.KEYSENSE = function(msg)
        KS:HandleSlash(msg)
    end

    self:Print("loaded. Type /ks to open.")
end


function KS:OnEvent(eventName, ...)
    if eventName == "ADDON_LOADED" then
        self:OnAddonLoaded(...)
        return
    end

    if not self.db then
        return
    end

    if eventName == "PLAYER_LOGIN" then
        self:CreateUI()
        return
    end

    if eventName == "LFG_LIST_APPLICANT_UPDATED"
        or eventName == "LFG_LIST_APPLICANT_LIST_UPDATED"
        or eventName == "LFG_LIST_ACTIVE_ENTRY_UPDATE" then

        if self.db.settings.autoShowOnApplicant then
            self:Show()
        elseif self.frame and self.frame:IsShown() then
            self:Refresh()
        end
    end
end


KS:SetScript("OnEvent", function(_, eventName, ...)
    KS:OnEvent(eventName, ...)
end)

KS:RegisterGameEvent("ADDON_LOADED")
KS:RegisterGameEvent("PLAYER_LOGIN")
KS:RegisterGameEvent("LFG_LIST_APPLICANT_UPDATED")
KS:RegisterGameEvent("LFG_LIST_APPLICANT_LIST_UPDATED")
KS:RegisterGameEvent("LFG_LIST_ACTIVE_ENTRY_UPDATE")
